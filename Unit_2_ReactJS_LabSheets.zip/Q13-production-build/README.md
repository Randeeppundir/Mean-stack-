# Q13. Application Boot and Production Build

1. `index.html` contains the page title and the `root` element.
2. `src/main.jsx` logs a startup message, imports `App`, and renders it inside `React.StrictMode`.
3. Run:
   ```bash
   npm install
   npm run dev
   npm run build
   npm run preview
   ```
4. Vite creates the production output in `dist/`. The preview command prints a local URL for the built app.
5. Take screenshots of the browser console, the `dist` folder, and the running preview.
