export default function App() {
  return <main className="profile">
    <h1>Application Boot and Production Build</h1>
    <p>Open the browser console to see the startup message from main.jsx.</p>
    <p>This page can be built with Vite and served using the preview command.</p>
  </main>;
}
