# Q10. Virtual DOM in Action

Run `npm install` and `npm run dev`. The app contains a live clock, a React counter, and a plain JavaScript counter using `innerHTML`. Open DevTools → Elements, inspect the counter text, and click each button to compare updates. React reconciles the changed UI; the plain example manually updates the DOM.
