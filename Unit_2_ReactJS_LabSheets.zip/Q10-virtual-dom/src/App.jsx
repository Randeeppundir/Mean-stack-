import { useEffect, useState } from "react";

function Clock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);
  return <p>Live clock: {time.toLocaleTimeString()}</p>;
}

function ReactCounter() {
  const [count, setCount] = useState(0);
  return <section><h2>React Counter</h2><p id="react-count">Count: {count}</p>
    <button onClick={() => setCount((value) => value + 1)}>Increment React counter</button></section>;
}

function PlainJsCounter() {
  useEffect(() => {
    let count = 0;
    const button = document.getElementById("plain-button");
    const output = document.getElementById("plain-count");
    const handleClick = () => { count += 1; output.innerHTML = `Count: ${count}`; };
    button.addEventListener("click", handleClick);
    return () => button.removeEventListener("click", handleClick);
  }, []);
  return <section><h2>Plain JavaScript Counter</h2><p id="plain-count">Count: 0</p>
    <button id="plain-button">Increment plain JS counter</button></section>;
}

export default function App() {
  return <main className="profile"><h1>Virtual DOM in Action</h1><Clock /><ReactCounter /><PlainJsCounter />
    <p>Inspect the Elements panel while clicking. React updates the changed text node; the plain JavaScript example directly changes innerHTML.</p>
  </main>;
}
