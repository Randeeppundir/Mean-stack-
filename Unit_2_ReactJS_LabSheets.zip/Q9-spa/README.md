# Q9. Single Page Application

Run `npm install` and `npm run dev`. Use Home, About, and Contact buttons to switch views using `useState`. Open browser DevTools → Network, enable Preserve log if desired, and switch views. You should not see a new document navigation for each button click.
