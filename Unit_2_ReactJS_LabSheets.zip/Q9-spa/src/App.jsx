import { useState } from "react";

const pages = {
  Home: <><h2>Home</h2><p>Welcome to the Home view.</p></>,
  About: <><h2>About</h2><p>This small app demonstrates a single-page interface.</p></>,
  Contact: <><h2>Contact</h2><p>Email: student@example.com</p></>
};

export default function App() {
  const [page, setPage] = useState("Home");
  return (
    <main className="profile">
      <h1>Single Page Application</h1>
      <nav className="buttons">
        {Object.keys(pages).map((name) => (
          <button key={name} onClick={() => setPage(name)}>{name}</button>
        ))}
      </nav>
      <section>{pages[page]}</section>
      <p>Current view: {page}. Switching views uses state; it does not reload the document.</p>
    </main>
  );
}
