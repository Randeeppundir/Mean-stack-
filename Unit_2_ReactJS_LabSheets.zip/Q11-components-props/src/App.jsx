function Header() {
  return <header><h1>Student Cards</h1><p>Components and props demonstration</p></header>;
}

function Footer() {
  return <footer><small>React JS Lab — MCA</small></footer>;
}

function Card({ name, course, marks }) {
  return <article className="card"><h2>{name}</h2><p>Course: {course}</p><p>Marks: {marks}</p></article>;
}

const students = [
  { id: 1, name: "Aarav", course: "MCA", marks: 82 },
  { id: 2, name: "Diya", course: "MCA", marks: 76 },
  { id: 3, name: "Rohan", course: "MCA", marks: 91 }
];

export default function App() {
  return <main className="profile"><Header />
    <div className="cards">{students.map((student) => <Card key={student.id} name={student.name} course={student.course} marks={student.marks} />)}</div>
    <Footer />
  </main>;
}
