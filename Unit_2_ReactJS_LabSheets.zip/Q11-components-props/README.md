# Q11. JSX, Components and Props

Run `npm install` and `npm run dev`. The app defines `Header`, `Footer`, and `Card` components. It renders three cards from an array with `map()` and provides a stable `key` for each card.
