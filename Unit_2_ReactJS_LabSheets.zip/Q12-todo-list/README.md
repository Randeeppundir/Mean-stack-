# Q12. State and Event Handling

Run `npm install` and `npm run dev`. Add tasks using the input and Add button (or Enter). Delete each task with its Delete button. State is managed with `useState`, and input/button events use `onChange`, `onClick`, and `onKeyDown`.
