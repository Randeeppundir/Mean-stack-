import { useState } from "react";

export default function App() {
  const [taskText, setTaskText] = useState("");
  const [tasks, setTasks] = useState([]);
  const addTask = () => {
    const trimmed = taskText.trim();
    if (!trimmed) return;
    setTasks((current) => [...current, { id: Date.now(), text: trimmed }]);
    setTaskText("");
  };
  const deleteTask = (id) => setTasks((current) => current.filter((task) => task.id !== id));

  return <main className="profile">
    <h1>To-Do List</h1>
    <div className="buttons">
      <input value={taskText} onChange={(event) => setTaskText(event.target.value)}
        onKeyDown={(event) => { if (event.key === "Enter") addTask(); }}
        placeholder="Enter a task" aria-label="Task name" />
      <button onClick={addTask}>Add</button>
    </div>
    {tasks.length === 0 ? <p>No tasks yet. Add your first task.</p> : <ul>
      {tasks.map((task) => <li key={task.id}>{task.text} <button onClick={() => deleteTask(task.id)}>Delete</button></li>)}
    </ul>}
  </main>;
}
