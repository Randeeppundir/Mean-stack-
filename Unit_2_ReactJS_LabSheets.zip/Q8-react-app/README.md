# Q8. Create and Run a React App

1. Replace `YOUR NAME` in `src/App.jsx`.
2. In this folder run:
   ```bash
   npm install
   npm run dev
   ```
3. Open the local URL printed by Vite.
4. Install React Developer Tools in your browser and inspect the component tree.

This folder is a Vite React project equivalent to the requested `npm create vite@latest myreact -- --template react` setup.
