export default function App() {
  return (
    <main className="profile">
      <h1>Hello, I'm Randeep Singh</h1>
      <p><strong>Course:</strong> MCA</p>
      <p><strong>College:</strong> COER University</p>
      <p>This React app was created with Vite.</p>
    </main>
  );
}
