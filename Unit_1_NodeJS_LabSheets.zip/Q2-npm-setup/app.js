const _ = require("lodash");

const names = ["randeep", "bhavna", "kritika"];
console.log("Node CLI and NPM setup is running.");
console.log("Names in title case:", _.map(names, _.startCase));
console.log("Last updated:", new Date().toLocaleTimeString());
