# Q2. Node CLI and NPM Setup

The `package.json` is included with `start` and `dev` scripts. From this folder run:

```bash
npm install
npm run dev
```

Edit and save `app.js` (for example, change the first console message). Nodemon should restart the app automatically. To run without automatic restart, use `npm start`.

To create the setup from scratch as requested:
```bash
mkdir node-lab
cd node-lab
npm init -y
npm install lodash
npm install --save-dev nodemon
```
Then add the scripts shown in `package.json`.
