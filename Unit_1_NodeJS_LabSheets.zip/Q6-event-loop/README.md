# Q6. Event Loop and Process Object

Run:
```bash
node eventloop.js
```

**Predicted order:** synchronous logs first; then `process.nextTick`; then Promise microtasks; then timer/immediate callbacks. The relative order of `setTimeout(0)` and `setImmediate()` can vary depending on where they are scheduled and the Node.js version/runtime context. Compare your actual output with this prediction. The program also prints process ID, platform, command-line arguments, and memory usage.
