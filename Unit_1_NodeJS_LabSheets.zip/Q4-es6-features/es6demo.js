// let and const
let score = 75;
const course = "MCA";
console.log("let score:", score);
console.log("const course:", course);

// Arrow function
const multiply = (a, b) => a * b;
console.log("Arrow function, 4 x 5:", multiply(4, 5));

// Template literal
const studentName = "Aman";
console.log(`Template literal: ${studentName} is studying ${course}.`);

// Object destructuring
const student = { name: "Aman", age: 22, city: "Roorkee" };
const { name, age } = student;
console.log("Object destructuring:", name, age);

// Array destructuring
const marks = [78, 84, 91];
const [first, second, third] = marks;
console.log("Array destructuring:", first, second, third);

// Spread operator
const moreMarks = [...marks, 88];
console.log("Spread operator:", moreMarks);

// Rest operator
function sum(...numbers) {
  return numbers.reduce((total, number) => total + number, 0);
}
console.log("Rest operator, sum:", sum(1, 2, 3, 4));

// Default parameter
function greet(person = "Student") {
  return `Hello, ${person}!`;
}
console.log("Default parameter:", greet());
console.log("Default parameter with argument:", greet("Randeep"));
