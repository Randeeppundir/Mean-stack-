# Q4. ES6 Features Program

Run:
```bash
node es6demo.js
```
The program demonstrates `let`, `const`, arrow functions, template literals, object and array destructuring, spread and rest operators, and default parameters.
