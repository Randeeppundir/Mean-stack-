# Q1. Install and Run Your First Program

1. Install the Node.js LTS release.
2. Verify installation:
   ```bash
   node -v
   npm -v
   ```
3. Open the REPL by typing `node`, then evaluate these five expressions:
   ```js
   2 + 3
   "Node.js".toUpperCase()
   [1, 2, 3].length
   Math.sqrt(81)
   new Date().getFullYear()
   ```
   Exit with `.exit`.
4. Replace `YOUR NAME` in `hello.js`.
5. Run:
   ```bash
   node hello.js
   ```
