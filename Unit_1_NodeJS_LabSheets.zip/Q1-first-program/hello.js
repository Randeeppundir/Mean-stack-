const name = "Randeep Singh";
const today = new Date().toLocaleDateString();

console.log(`Hello, my name is ${name}.`);
console.log(`Today's date is ${today}.`);
