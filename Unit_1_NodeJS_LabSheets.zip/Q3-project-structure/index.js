import { add, subtract } from "./src/utils.js";

console.log("Addition (12 + 5):", add(12, 5));
console.log("Subtraction (12 - 5):", subtract(12, 5));
