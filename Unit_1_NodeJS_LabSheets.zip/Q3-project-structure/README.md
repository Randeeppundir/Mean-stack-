# Q3. Project Directory Structure

Files:
- `index.js` — imports and calls utility functions.
- `src/utils.js` — exports `add()` and `subtract()` using ES module syntax.
- `package.json` — sets `"type": "module"`.
- `.gitignore` — ignores `node_modules`.

Run:
```bash
npm start
```

The final version uses ES modules. For the first CommonJS stage, use `module.exports = { add, subtract }` in `utils.js` and `const { add, subtract } = require("./src/utils")` in `index.js`; then switch to the final ES module version provided here.
