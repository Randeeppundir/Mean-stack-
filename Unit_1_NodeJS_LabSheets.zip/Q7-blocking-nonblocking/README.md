# Q7. Blocking vs. Non-blocking Code

## File reading demo
```bash
node file-read-demo.js
```
This reads `sample.txt` using `readFileSync`, callback-based `readFile`, and `fs.promises.readFile` with `async/await`.

## HTTP server demo
```bash
npm start
```
Open `http://localhost:3000/fast` and `http://localhost:3000/slow` in separate browser tabs. If `/slow` is being processed, it blocks the single Node.js event loop for roughly five seconds, so the `/fast` request can also be delayed. Test by starting `/slow` and quickly opening `/fast`.

The busy loop is intentionally inefficient for this lab only. Do not use blocking loops in production servers.
