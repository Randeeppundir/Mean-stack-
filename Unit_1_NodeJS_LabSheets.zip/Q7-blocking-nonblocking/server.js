const http = require("node:http");

const server = http.createServer((req, res) => {
  if (req.url === "/fast") {
    res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Fast route responded immediately.\n");
    return;
  }

  if (req.url === "/slow") {
    // Intentionally blocks the Node.js event loop for about five seconds.
    const start = Date.now();
    while (Date.now() - start < 5000) {
      // Busy wait for demonstration only; never use this in production.
    }
    res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Slow route finished after a blocking loop.\n");
    return;
  }

  res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
  res.end("Open /fast or /slow.\n");
});

server.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
  console.log("Try http://localhost:3000/fast and http://localhost:3000/slow");
});
