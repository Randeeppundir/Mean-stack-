const fs = require("node:fs");
const path = require("node:path");

const filePath = path.join(__dirname, "sample.txt");

// Synchronous (blocking) read
console.log("1. Before readFileSync");
const syncText = fs.readFileSync(filePath, "utf8");
console.log("2. Sync content:", syncText.trim());

// Callback-based asynchronous read
console.log("3. Before fs.readFile callback");
fs.readFile(filePath, "utf8", (error, data) => {
  if (error) return console.error("Callback read error:", error);
  console.log("5. Callback content:", data.trim());
});

// Promise API with async/await
async function readWithPromises() {
  try {
    const data = await fs.promises.readFile(filePath, "utf8");
    console.log("6. Promise/async-await content:", data.trim());
  } catch (error) {
    console.error("Promise read error:", error);
  }
}

console.log("4. After scheduling callback read");
readWithPromises();
