class Student {
  constructor(name, course, marks) {
    this.name = name;
    this.course = course;
    this.marks = marks;
  }

  display() {
    return `${this.name} (${this.course}) - ${this.marks} marks`;
  }
}

class GradStudent extends Student {
  constructor(name, course, marks, specialization) {
    super(name, course, marks);
    this.specialization = specialization;
  }

  display() {
    return `${super.display()} - Specialization: ${this.specialization}`;
  }
}

const students = [
  new Student("Aarav", "MCA", 78),
  new Student("Diya", "MCA", 56),
  new GradStudent("Rohan", "MCA", 88, "AI"),
  new Student("Meera", "MCA", 63),
  new GradStudent("Kabir", "MCA", 49, "Web Development")
];

console.log("All students:");
students.forEach((student) => console.log(student.display()));

console.log("\nStudents scoring above 60:");
const selectedStudents = students
  .filter((student) => student.marks > 60)
  .map((student) => student.display());

selectedStudents.forEach((student) => console.log(student));
