# Q5. ES6 Classes

Run:
```bash
node students.js
```
The program defines a `Student` class, a `GradStudent` subclass, creates five objects, and uses `filter()` and `map()` to print students with marks above 60.
